<script setup lang="ts">
import { RouterLink, RouterView } from 'vue-router'
import MyHeader from './components/MyHeader.vue';
import HomeView from './views/HomeView.vue';
import PayView from './views/PayView.vue';
</script>

<template>
  <HomeView/>
</template>
