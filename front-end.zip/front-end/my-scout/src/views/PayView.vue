<script setup lang="ts">
import MyHeader from "@/components/MyHeader.vue";
</script>
<template>
    <main>
        <MyHeader />
        <div class="about">
            <h1>This is an about page</h1>
        </div>
    </main>

</template>